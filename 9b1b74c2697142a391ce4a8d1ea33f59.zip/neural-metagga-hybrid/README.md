# Neural Meta-GGA Hybrid

### Variational learning of a global-hybrid exchange–correlation functional with JAX and PySCF

Author: Aditya Nagarkar · Version: 0.2.0 · Status: experimental research scaffold

> No trained model, validated chemical benchmark, or speedup claim is included.
> The new source passed syntax checks and NumPy algebra tests in the packaging
> environment. JAX/PySCF execution was not available there; see
> [BUILD_VALIDATION.json](BUILD_VALIDATION.json) and [validation status](docs/STATUS.md).

This project combines direct orbital optimization, neural semilocal corrections,
and a learnable global fraction of Hartree–Fock exchange. It is based on the
provided molecular neural-DFT prototype and is inspired by D4FT's approach to
variational orbital minimization. It is an independent small-molecule implementation,
not the official D4FT library or a reproduction of its published scaling results.

## Contents

- [Motivation](#motivation)
- [Method](#method)
- [Dataset and units](#dataset-and-units)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Full pilot experiment](#full-pilot-experiment)
- [Interpreting results](#interpreting-results)
- [Differences from the supplied prototype](#differences-from-the-supplied-prototype)
- [Relationship to published work](#relationship-to-published-work)
- [Repository layout](#repository-layout)
- [Limitations and research roadmap](#limitations-and-research-roadmap)
- [Reproducibility and publishing](#reproducibility-and-publishing)
- [References](#references)

## Motivation

Kohn–Sham density functional theory replaces an interacting many-electron problem
with a reference orbital problem, while exchange and correlation enter through an
approximate functional. Better numerical optimization and a better functional are
separate improvements: solving an approximate functional more accurately does not
remove that functional's physical approximation error [1,2].

The research question here is:

> Can a neural correction using density, density-gradient and kinetic-energy-density
> information, together with a learned global exchange fraction, improve a controlled
> small-molecule energy benchmark while preserving reliable orbital optimization?

The repository is designed to test this question. The six-molecule training set is
a pilot, not evidence of a universal functional. There is no demonstrated novelty
or superiority claim over D4FT, DQC, DM21, EG-XC or Skala.

## Method

### 1. Molecular data from PySCF

PySCF supplies the overlap matrix, one-electron integrals, dense two-electron
integrals, nuclear repulsion, numerical quadrature weights, AO values, and first
AO derivatives. Analytic AO kinetic/core and Coulomb energies are used; the grid
is used for the semilocal XC contribution and orbital descriptors [2].

Reference preparation runs HF, CCSD(T), and same-grid UKS calculations with
exchange-only LDA, LDA/VWN, PBE and PBE0. Failed reference convergence stops the
calculation instead of substituting a lower-level label. CCSD(T) is an approximate
finite-basis reference, not an exact energy [3].

### 2. Orthonormal orbitals without an SCF loop

For real occupied orbital rows \(C_\sigma\), require

\[
C_\sigma S C_\sigma^\mathsf{T}=I.
\]

If \(S=U\Lambda U^\mathsf{T}\), define \(D=U\Lambda^{-1/2}\).
A reduced QR decomposition \(W_\sigma^\mathsf{T}=Q_\sigma R_\sigma\) gives

\[
C_\sigma=Q_\sigma^\mathsf{T}D^\mathsf{T}.
\]

This satisfies the overlap constraint exactly in ideal arithmetic. We optimize
unconstrained \(W_\alpha,W_\beta\) using automatic differentiation. This direct
minimization strategy is related to D4FT [1]. QR does not guarantee a global minimum,
and rank-deficient orbital parameters remain a numerical hazard.

### 3. Neural global-hybrid energy

With \(P_\sigma=C_\sigma^\mathsf{T}C_\sigma\), \(P=P_\alpha+P_\beta\),

\[
E_\theta = \operatorname{Tr}[P(T+V)] + E_J[P]
 + a_\theta E_x^{\mathrm{HF}}
 + (1-a_\theta)\int e_x^{\mathrm{LSDA}}F_{x,\theta}\,d\mathbf r
 + \int \rho\epsilon_c^{\mathrm{proto}}F_{c,\theta}\,d\mathbf r
 + E_{\mathrm{nuc}}.
\]

The spin-scaled Dirac exchange energy per volume is

\[
e_x^{\mathrm{LSDA}}=C_x2^{1/3}
(\rho_\alpha^{4/3}+\rho_\beta^{4/3}),\qquad
C_x=-\frac34\left(\frac3\pi\right)^{1/3}.
\]

The correlation term retains the prototype's spin-independent Chachiyo-form
expression. It is deliberately not described as a verified full spin-polarized
Chachiyo implementation. Its primary-source parameter conventions still need an
independent audit; see [theory](docs/THEORY.md).

The trainable exchange fraction is

\[
a_\theta=0.5\,\operatorname{sigmoid}(a_{\mathrm{raw}}),
\qquad 0<a_\theta<0.5.
\]

The initial raw value -0.847 gives approximately 15% exact exchange. The initial
network therefore represents a hybrid with correlation—not the x-only baseline.

### 4. Features and architecture

At each grid point, the network uses seven features:

1. \(\log(1+\rho)\).
2. Spin polarization \(\zeta=(\rho_\alpha-\rho_\beta)/\rho\).
3. \(\log(1+|\nabla\rho_\alpha|^2)\).
4. \(\log(1+|\nabla\rho_\beta|^2)\).
5. \(\log(1+\tau_\alpha)\).
6. \(\log(1+\tau_\beta)\).
7. A normalized iso-orbital indicator \((\tau-\tau_W)/\tau\).

Here \(\tau_\sigma=\frac12\sum_i|\nabla\psi_{i\sigma}|^2\) and
\(\tau_W=|\nabla\rho|^2/(8\rho)\). The final feature is not the conventional
meta-GGA \((\tau-\tau_W)/\tau_{\mathrm{uniform}}\) definition.
These descriptors use a fixed atomic-unit convention and do not enforce uniform
coordinate scaling. They are not all dimensionless reduced physical variables.

The default MLP has three 128-unit GELU layers and two zero-initialized output
channels. Shared weights process the original and spin-swapped features, and the
outputs are averaged to enforce global alpha/beta label symmetry. Corrections are
bounded by \(F=1+0.5\tanh(f_\theta)\), so \(0.5<F<1.5\).
This is a stabilization choice, not a rigorous universal functional constraint.
All model parameters and computations explicitly request FP64.

### 5. Training without unrolling the orbital optimizer

The inner problem minimizes energy at fixed neural parameters. For a smooth
stationary branch, the envelope theorem gives

\[
\frac{dE^*(\theta)}{d\theta}
=\left.\frac{\partial E(W,\theta)}{\partial\theta}\right|_{W=W^*(\theta)}.
\]

The outer objective is mean absolute total-energy error against the configured
CCSD(T) targets. This implementation freezes converged orbitals for that derivative;
it does not differentiate through the Adam iterations.

This is justified only under the stationary-solution assumptions. A small orbital
residual alone does not bound gradient error without response conditioning.
Degeneracies or changing minimum branches also matter. Training stops if the
inner convergence gate fails. A separate finite-difference script re-solves the
orbitals at perturbed parameter values to audit the gradient numerically.
The same shortcut is not generally valid for density or force losses.

## Dataset and units

| Split | Systems | Purpose |
|---|---|---|
| Train | H2, He, LiH, N, H2O, CH4 | Small pilot fit |
| Test | CO, F2, HF | Pilot transfer evaluation |

- Basis: def2-SVP in `configs/small.json`.
- Quadrature: PySCF level 4, shared with UKS baselines.
- Geometry input: Angstrom; internal integral/orbital expressions use atomic units.
- Energies: Hartree; reporting uses 627.509 kcal/mol per Hartree, matching the prototype.
- PySCF `spin` is \(N_\alpha-N_\beta=2S\) for the specified reference occupations.
  Nitrogen uses spin=3; all other supplied systems use spin=0.
- Fluorine occurs only in the test set, so F2/HF test unseen-element transfer as
  well as new molecules. CO is a new molecular composition, not an unseen-element test.
- No validation split is provided. Add one before hyperparameter selection.
- These are the supplied geometries, not independently optimized structures.

Exact geometries, seeds, model settings and convergence thresholds are explicit
in the JSON configs. The H2/STO-3G smoke config is for plumbing checks only.

## Installation

Use a clean Python 3.11 environment. The build environment used Python 3.12 for
syntax and dependency-free tests; the scientific dependency stack remains untested.

```bash
python -m venv .venv
source .venv/bin/activate                 # Linux/macOS
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e '.[dev]'
pip check
pytest -v
```

The dependency ranges in `pyproject.toml` are provisional compatibility bounds,
not an experimentally verified lockfile. Record the resolved environment before
reporting results. CPU is the initial target. GPU acceleration requires an appropriate
JAX installation for your platform; `pip install jax` is not a CUDA guarantee [9].
FP64 speed and memory use depend strongly on the device.

## Quick start

Run from the extracted repository root:

```bash
nmh prepare --config configs/smoke.json --run-dir runs/smoke
nmh validate --config configs/smoke.json --run-dir runs/smoke
nmh train --config configs/smoke.json --run-dir runs/smoke
nmh evaluate --config configs/smoke.json --run-dir runs/smoke
```

| Command | What it does |
|---|---|
| `prepare` | Generates integrals, HF starts and checked reference calculations |
| `validate` | Compares direct-minimized x-only energy with matched-grid PySCF UKS |
| `train` | Fits neural parameters on only the configured training molecules |
| `evaluate` | Re-solves with the saved parameters and exports errors and diagnostics |

The smoke run trains only two epochs. Passing it does not establish chemical
accuracy or broad numerical robustness. These scientific commands were not
executed while packaging this repository.

### Audit the energy gradient

```bash
python scripts/check_envelope.py \
  --config configs/smoke.json \
  --run-dir runs/smoke \
  --molecule H2
```

This compares a random-direction envelope derivative against central differences
across several step sizes, with an orbital re-solve at every perturbation. It writes
a CSV, not an automatic scientific certification. Inspect the step-size plateau,
residuals and possible branch changes; repeat with multiple seeds and tighter solves.

## Full pilot experiment

```bash
nmh prepare --config configs/small.json --run-dir runs/small
nmh validate --config configs/small.json --run-dir runs/small
nmh train --config configs/small.json --run-dir runs/small
nmh evaluate --config configs/small.json --run-dir runs/small
python -m pip freeze > runs/small/environment.txt
```

Preparation computes all nine reference systems, including CCSD(T), and stores
dense ERIs. Start small: both reference generation and compiled orbital gradients
can consume substantial time/memory. The ERI-size guard limits only the estimated
dense integral array, not total host/device/compilation memory.

A config digest prevents accidental reuse of an incompatible run directory.
Changing convergence thresholds requires a new directory and freshly prepared
reference data. Warm-start training tracks one solution branch; evaluation also
uses perturbed HF starts to expose some local-minimum sensitivity.

### Optional plot

```bash
python scripts/plot_results.py runs/small/evaluate.csv
```

Install matplotlib separately for plotting. No example accuracy plot is bundled,
because no trained evaluation has been run.

## Interpreting results

Run artifacts are saved under the selected run directory:

| Artifact | Meaning |
|---|---|
| `manifest.json` | Config, config digest, Python/packages, backend and devices |
| `data/<system>/integrals.npz` | AO arrays, grids and HF orbital starts |
| `data/<system>/references.json` | Method-labeled energies and convergence/spin metadata |
| `parameters.msgpack` | Neural parameters saved after each epoch |
| `optimizer.msgpack` | Outer optimizer state; resume command is not implemented |
| `training.json` | Pre-update train MAE and post-update exchange fraction |
| `validate.csv` | Solver discrepancy against x-only UKS, not error against CCSD(T) |
| `evaluate.csv` | Learned-model and baseline errors against CCSD(T) |
| `*_starts.json` | Per-start energy and orbital convergence trajectories |
| `*_physics.json` | AO/grid electron counts and kinetic-energy cross-check |
| `*_summary.json` | Converged-sample MAE, RMSE, max error and failure counts |

The stage exits nonzero if a molecule has no converged orbital start. Evaluation
excludes failed molecules from summary metrics and reports failure counts; never
present that conditional MAE without its sample count and failures.
Exchange-only validation also exits nonzero if its energy discrepancy exceeds the
configured tolerance. A lower direct-minimization energy may indicate a different
SCF minimum or broken symmetry; it is not automatically a better functional.

Keep these comparisons separate:

1. Solver correctness: same-functional, same-grid, same-search-domain energies.
2. Functional quality: converged learned XC versus consistent reference energies.
3. Chemical prediction: atomization/reaction energies, spin gaps and dissociation curves.

Absolute total-energy fitting alone does not establish accuracy on item 3.

## Differences from the supplied prototype

| Original behavior | This scaffold |
|---|---|
| `lda,` labeled as an LSDA baseline | Explicitly called exchange-only |
| Fixed 600 inner updates | Energy and projected orbital-gradient convergence gates |
| Final logged energy precedes last update | Energy recomputed at returned orbitals |
| JIT recreated inside each solve | Cached step, neural parameters passed dynamically |
| Ordered spin-channel neural features | Shared-network spin symmetrization by default |
| Unbounded enhancement corrections | Bounded corrections by default |
| Default Flax parameter dtype | Explicit FP64 parameters |
| Default-grid RKS baseline vs unrestricted custom orbitals | Same-grid UKS comparison |
| No persistent run outputs | Manifests, references, checkpoints, diagnostics and metrics |

For a closer architecture ablation, set `symmetrize_spin=false` and
`residual_bound=null` in a copied JSON config and use a new run directory.
This does not recreate the original initialization, restart policy, clipping,
parameter precision or optimizer trajectory exactly. It is not bitwise reproduction.

The whitening matrix and the supplied final exact-exchange contraction were not
identified as errors. They are retained and covered by algebra/backend tests.
See [the full audit](docs/CODE_AUDIT.md).

## Relationship to published work

| Work | Relevant connection | What this repository does not reproduce |
|---|---|---|
| D4FT, ICLR 2023 [1] | Differentiable direct orbital minimization | Official integral engine, stochastic/scaling experiments or published performance |
| Kasim–Vinko / DQC, PRL 2021 [4] | Neural XC learning inside differentiable molecular DFT | Its data, objective, differentiable SCF framework or reported generalization |
| DM21, Science 2021 [5] | Learning XC with fractional-charge/spin constraints | Its functional, model weights, dataset or benchmark protocol |
| EG-XC, ICLR 2025 [6] | Nonlocal equivariant density representation and SCF-differentiated energy training | Its GNN, density point cloud or benchmark results |
| Skala-related work [7] | Larger-scale learned-XC/data/implementation research context | A verified Skala architecture reproduction or direct performance comparison |

D4FT's official repository documents both direct minimization and componentwise
PySCF cross-checks [1]. DQC established neural XC training through differentiable
DFT, so that broad idea is not new [4]. EG-XC goes beyond the semilocal neural
features used here by representing nonlocal density interactions with an equivariant
GNN [6]. DM21 motivates constrained training, but its fractional-electron generalization
was also the subject of a published comment and response; read both before making
sweeping claims [5,8].

The comparison table is methodological context, not a head-to-head benchmark.
Read [the literature notes](docs/LITERATURE.md) for evidence scope and open questions.

## Repository layout

```text
src/neural_metagga/     Model, energy, backend, solver, training, CLI and algebra
configs/               Smoke and supplied small-molecule experiment
scripts/               Gradient check and result plotting
notebooks/             Minimal command-based quick start
tests/                Algebra, spin-symmetry and PySCF cross-checks
docs/                 Theory, audit, literature, experiments and validation status
archive/               Original attached Colab export, unmodified
.github/workflows/     CPU tests and smoke validation
```

The legacy export is provenance material, not package source. It contains notebook
syntax and a different 6-31g experimental workflow; it is excluded from syntax
compilation and should not be executed as part of this package.

## Limitations and research roadmap

### Before reporting any accuracy

- Run scientific dependencies, backend tests and smoke validation locally/CI.
- Verify electron counts, tau quadrature, grid convergence and multiple orbital starts.
- Establish re-solved finite-difference gradient agreement.
- Add validation data and separate test usage from hyperparameter selection.
- Verify spin-dependent correlation conventions against primary sources.

### Controlled research experiments

- Compare local prototype XC, fixed-alpha hybrids, alpha-only learning,
  neural-only learning and the full model.
- Add atomization/reaction energies and H2/LiH/HF/F2 dissociation curves.
- Monitor open-shell contamination and the validity of stretched-bond references.
- Compare dimensionless reduced descriptors and physical constraints.
- Measure sensitivity to basis, grid, molecule size and unseen elements.
- Separate compilation time from synchronized warm execution timing.

### Implementation work remaining

- Resume support and atomic/checksummed checkpoint recovery.
- Density fitting, grid chunking and memory-aware compiled-solver scheduling.
- Restricted-orbital ablations and systematic SCF stability analysis.
- Force/density-loss response derivatives; fractional occupations.
- Larger datasets, primary-paper reproduction and exact dependency lockfiles.

Dense ERI storage scales as O(B^4). This scaffold does not establish favorable
large-system scaling. Bounded neural outputs are not exact physical constraints;
spin-label symmetry is not a full noncollinear spin treatment. CCSD(T)/def2-SVP
fitting can learn reference/basis limitations as well as useful corrections.

## Reproducibility and publishing

Before release, archive the exact package environment, config, code commit,
reference provenance, failures and result artifacts. Generated `runs/` are ignored
by Git; use an appropriate external archive for large integrals/checkpoints.
The manifest currently records a config digest, not hashes of every generated array.
No pretrained parameters or results have been deposited.

To initialize your extracted repository:

```bash
git init
git add .
git commit -m "Initial neural hybrid meta-GGA research scaffold"
git branch -M main
git remote add origin YOUR_ACTUAL_GITHUB_REMOTE_URL
git push -u origin main
```

Choose a license and verify legacy content rights before distributing the project
as open source. No license was selected on the author's behalf; see
[LICENSE_DECISION.md](LICENSE_DECISION.md). No remote repository was created.
Software citation metadata is in [CITATION.cff](CITATION.cff); cite the upstream
methods and libraries actually used, not this scaffold alone.

## References

[1] Li et al., *D4FT: A Deep Learning Approach to Kohn-Sham Density Functional Theory*, ICLR 2023.
[Paper](https://openreview.net/forum?id=aBWnqqsuot7) ·
[Official implementation](https://github.com/sail-sg/d4ft).

[2] PySCF, [DFT user guide](https://pyscf.org/user/dft.html): generalized KS,
XC grammar, quadrature and kinetic-energy density.

[3] PySCF, [coupled-cluster user guide](https://pyscf.org/user/cc.html).

[4] M. F. Kasim and S. M. Vinko, *Learning the Exchange-Correlation Functional from
Nature with Fully Differentiable Density Functional Theory*, Phys. Rev. Lett. 127,
126403 (2021). [DOI](https://doi.org/10.1103/PhysRevLett.127.126403) ·
[DQC implementation](https://github.com/diffqc/dqc).

[5] Kirkpatrick et al., *Pushing the frontiers of density functionals by solving
the fractional electron problem*, Science 374, 1385–1389 (2021).
[DOI](https://doi.org/10.1126/science.abj6511).

[6] N. Gao, E. Eberhard and S. Günnemann, *Learning Equivariant Non-Local Electron
Density Functionals*, ICLR 2025.
[Proceedings](https://proceedings.iclr.cc/paper_files/paper/2025/hash/7d95d65059958ba8667be1f642c6447c-Abstract-Conference.html).

[7] Microsoft Research, [DFT publications](https://www.microsoft.com/en-us/research/project/dft/publications/),
including *Accurate and scalable exchange-correlation with deep learning* (2025)
and Skala molecular implementation work (2026). Listing verification is not a
full-paper architecture review.

[8] DM21 [Comment](https://doi.org/10.1126/science.abq3385) and
[Response](https://doi.org/10.1126/science.abq4282), Science (2022).

[9] JAX, [installation documentation](https://docs.jax.dev/en/latest/installation.html).

Online source review and packaging date: 1 November 2026. Evidence depth and
unverified primary-source details are documented in `docs/LITERATURE.md`.
