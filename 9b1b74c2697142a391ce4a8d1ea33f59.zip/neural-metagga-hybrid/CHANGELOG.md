# Changelog

## 0.2.0 — 2026-11-01

Rebuilt complete source archive and expanded the research README with a focused
online literature review, evidence boundaries, equations, commands and limitations.
Added configurable spin symmetry/output bounding, physical grid diagnostics,
MAE/RMSE/max-error summaries, gradient-check and plotting scripts, quick-start
notebook, CI, citation metadata and legacy provenance.

The earlier chat-generated archive is not present in this execution environment;
this is a fresh reconstruction, not a verified patch/diff against that archive.
