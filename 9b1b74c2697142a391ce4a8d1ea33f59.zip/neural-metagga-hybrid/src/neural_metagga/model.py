import jax
import jax.numpy as jnp
import flax.linen as nn


class NeuralMetaGGA(nn.Module):
    width: int=128
    depth: int=3
    symmetrize_spin: bool=True
    residual_bound: float | None=.5

    @nn.compact
    def __call__(self,ra,rb,ga,gb,ta,tb):
        def features(a,b,ag,bg,at,bt):
            rho=jnp.maximum(a+b,1e-12)
            tau=jnp.maximum(at+bt,1e-12)
            tw=.125*jnp.sum((ag+bg)**2,axis=-1)/rho
            return jnp.stack([jnp.log1p(rho),(a-b)/rho,
                jnp.log1p(jnp.sum(ag**2,axis=-1)),jnp.log1p(jnp.sum(bg**2,axis=-1)),
                jnp.log1p(jnp.maximum(at,0)),jnp.log1p(jnp.maximum(bt,0)),(tau-tw)/tau],axis=-1)
        layers=[nn.Dense(self.width,dtype=jnp.float64,param_dtype=jnp.float64,name=f'hidden_{i}')
                for i in range(self.depth)]
        head=nn.Dense(2,dtype=jnp.float64,param_dtype=jnp.float64,
                      kernel_init=nn.initializers.zeros,name='head')
        def apply_layers(x):
            for layer in layers:
                x=nn.gelu(layer(x))
            return head(x)
        raw=apply_layers(features(ra,rb,ga,gb,ta,tb))
        if self.symmetrize_spin:
            raw=.5*(raw+apply_layers(features(rb,ra,gb,ga,tb,ta)))
        correction=raw if self.residual_bound is None else self.residual_bound*jnp.tanh(raw)
        raw_alpha=self.param('alpha_ex_raw',nn.initializers.constant(-.847),(),jnp.float64)
        return 1+correction[...,0],1+correction[...,1],.5*jax.nn.sigmoid(raw_alpha)


def initialize(model,seed=42):
    r=jnp.ones(2,dtype=jnp.float64);g=jnp.ones((2,3),dtype=jnp.float64)
    return model.init(jax.random.PRNGKey(seed),r,r,g,g,r,r)
