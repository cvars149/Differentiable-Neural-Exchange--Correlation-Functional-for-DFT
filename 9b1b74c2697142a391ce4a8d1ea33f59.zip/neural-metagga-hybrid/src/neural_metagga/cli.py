import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path
import numpy as np
from .numerics import error_metrics


def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False))


def main():
    parser=argparse.ArgumentParser(description='Variational neural hybrid functional experiments')
    parser.add_argument('stage',choices=['prepare','validate','train','evaluate'])
    parser.add_argument('--config',default='configs/small.json')
    parser.add_argument('--run-dir',default='runs/small')
    args=parser.parse_args()
    import jax
    jax.config.update('jax_enable_x64',True)
    from flax import serialization
    from .backend import prepare,save,load
    from .model import NeuralMetaGGA,initialize
    from .energy import Energy
    from .solver import Solver
    from .training import train
    cfg=json.loads(Path(args.config).read_text());run=Path(args.run_dir);run.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
    manifest=run/'manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())['config_sha256']!=digest:
        raise ValueError('Config mismatch: choose a new run directory')
    if args.stage=='prepare':
        dump(manifest,dict(config=cfg,config_sha256=digest,python=platform.python_version(),platform=platform.platform(),
            backend=jax.default_backend(),devices=[str(x) for x in jax.devices()],
            versions={n:importlib.metadata.version(n) for n in ['jax','jaxlib','flax','optax','pyscf','numpy']}))
        for name,spec in cfg['molecules'].items():
            data,ref=prepare(spec,cfg['basis'],cfg['grid_level']);ref['geometry']=spec
            save(run/'data'/name,data,ref)
        return
    if not manifest.exists():
        raise FileNotFoundError('Run prepare first')
    model=NeuralMetaGGA(**cfg['model']);params=initialize(model,cfg['seed'])
    records={n:load(run/'data'/n) for n in cfg['molecules']}
    mode='xonly' if args.stage=='validate' else 'hybrid'
    solvers={n:Solver(Energy(d,model,mode),**cfg['solver']) for n,(d,_) in records.items()}
    if args.stage=='train':
        def checkpoint(p,state,history):
            (run/'parameters.msgpack').write_bytes(serialization.to_bytes(p))
            (run/'optimizer.msgpack').write_bytes(serialization.to_bytes(state))
            dump(run/'training.json',history);print(json.dumps(history[-1]),flush=True)
        train({n:solvers[n] for n in cfg['train']},{n:records[n] for n in cfg['train']},
              params,callback=checkpoint,**cfg['training'])
        return
    if args.stage=='evaluate':
        params=serialization.from_bytes(params,(run/'parameters.msgpack').read_bytes())
    rows=[]
    for name,(d,ref) in records.items():
        attempts=[]
        for k in range(cfg['n_starts']):
            rng=np.random.default_rng(cfg['seed']+k)
            wa=d['wa'] if k==0 else d['wa']+.1*rng.normal(size=d['wa'].shape)
            wb=d['wb'] if k==0 else d['wb']+.1*rng.normal(size=d['wb'].shape)
            attempts.append(solvers[name].solve(params,wa,wb))
        valid=[r for r in attempts if r.converged];best=min(valid or attempts,key=lambda r:r.energy)
        dump(run/f'{args.stage}_{name}_starts.json',[dict(energy_ha=r.energy,converged=r.converged,history=r.history) for r in attempts])
        dump(run/f'{args.stage}_{name}_physics.json',solvers[name].physical_diagnostics(best))
        target=ref['xonly'] if args.stage=='validate' else ref['ccsd_t']
        row=dict(molecule=name,split='train' if name in cfg['train'] else 'test',energy_ha=best.energy,
                 target_ha=target,signed_error_ha=best.energy-target,abs_error_kcal_mol=abs(best.energy-target)*627.509,
                 converged=best.converged,orbital_residual=best.residual,converged_starts=len(valid),starts=len(attempts))
        for baseline in ('xonly','lda_vwn','pbe','pbe0'):
            row[baseline+'_signed_error_ha']=ref[baseline]-ref['ccsd_t']
        rows.append(row);print(json.dumps(row),flush=True)
    with (run/f'{args.stage}.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary={}
    for split in ('train','test'):
        selected=[r for r in rows if r['split']==split]
        eligible=[r for r in selected if r['converged']]
        summary[split]=error_metrics([r['signed_error_ha'] for r in eligible])
        summary[split]['failed_molecules']=len(selected)-len(eligible)
        summary[split]['target']='same-grid UKS x-only' if args.stage=='validate' else 'finite-basis CCSD(T)'
    dump(run/f'{args.stage}_summary.json',summary)
    if any(not r['converged'] for r in rows):
        raise SystemExit('Unconverged molecules: do not report as validated results')
    if args.stage=='validate' and any(abs(r['signed_error_ha'])>cfg['validation_tol_ha'] for r in rows):
        raise SystemExit('Exchange-only agreement failed: inspect grids, stationarity and local minima')


if __name__=='__main__':
    main()
