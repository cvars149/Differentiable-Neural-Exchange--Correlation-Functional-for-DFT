"""Real AO energy and grid observables, in atomic units."""
import jax.numpy as jnp


def coefficients(w,d):
    if w.shape[0]==0:
        return jnp.zeros((0,d.shape[0]),dtype=d.dtype)
    q,_=jnp.linalg.qr(w.T,mode='reduced')
    return q.T@d.T


def fields(c,phi,grad_phi):
    psi=phi@c.T
    gp=jnp.einsum('gbx,ib->gix',grad_phi,c)
    return (jnp.sum(psi**2,axis=1),2*jnp.einsum('gi,gix->gx',psi,gp),
            .5*jnp.sum(gp**2,axis=(1,2)))


def dirac_x(ra,rb):
    return -.7385587663820224*2**(1/3)*(jnp.maximum(ra,0)**(4/3)+jnp.maximum(rb,0)**(4/3))


def prototype_correlation(ra,rb):
    rho=jnp.maximum(ra+rb,1e-12)
    rs=(.75/(jnp.pi*rho))**(1/3)
    # Inherited unpolarized Chachiyo-form expression; NOT spin-dependent LSDA correlation.
    return -.01554535*jnp.log1p(20.64336/rs+20.64336/rs**2)


class Energy:
    def __init__(self,data,model,mode='hybrid'):
        if mode not in ('xonly','local','hybrid'):
            raise ValueError(mode)
        self.data={k:jnp.asarray(v) for k,v in data.items()}
        self.model,self.mode=model,mode

    def components(self,ca,cb,params):
        d=self.data
        pa,pb=ca.T@ca,cb.T@cb;p=pa+pb
        core=jnp.sum(p*d['hcore'])
        hartree=.5*jnp.einsum('ij,kl,ijkl->',p,p,d['eri'])
        exact=-.5*sum(jnp.einsum('il,jk,ijkl->',q,q,d['eri']) for q in (pa,pb))
        ra,ga,ta=fields(ca,d['phi'],d['grad_phi'])
        rb,gb,tb=fields(cb,d['phi'],d['grad_phi'])
        xvol=dirac_x(ra,rb)
        if self.mode=='xonly':
            xc=jnp.dot(d['weights'],xvol)
        elif self.mode=='local':
            xc=jnp.dot(d['weights'],xvol+(ra+rb)*prototype_correlation(ra,rb))
        else:
            fx,fc,alpha=self.model.apply(params,ra,rb,ga,gb,ta,tb)
            xc=alpha*exact+(1-alpha)*jnp.dot(d['weights'],xvol*fx)
            xc+=jnp.dot(d['weights'],(ra+rb)*prototype_correlation(ra,rb)*fc)
        return dict(core=core,hartree=hartree,xc=xc,nuclear=d['enuc'])

    def from_coefficients(self,ca,cb,params):
        return sum(self.components(ca,cb,params).values())

    def __call__(self,wa,wb,params):
        return self.from_coefficients(coefficients(wa,self.data['D']),coefficients(wb,self.data['D']),params)
