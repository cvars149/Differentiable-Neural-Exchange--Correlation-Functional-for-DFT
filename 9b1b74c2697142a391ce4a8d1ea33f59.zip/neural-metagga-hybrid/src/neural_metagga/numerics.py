import numpy as np


def whitening(s, threshold=1e-10):
    values, vectors = np.linalg.eigh(s)
    if values.min() <= threshold:
        raise ValueError('Ill-conditioned overlap: use explicit AO rank reduction')
    return vectors / np.sqrt(values)[None,:]


def jk_energy(pa,pb,eri):
    p=pa+pb
    return (.5*np.einsum('ij,kl,ijkl->',p,p,eri),
            -.5*sum(np.einsum('il,jk,ijkl->',q,q,eri) for q in (pa,pb)))


def dirac_density(ra,rb):
    return -.7385587663820224*2**(1/3)*(np.maximum(ra,0)**(4/3)+np.maximum(rb,0)**(4/3))


def error_metrics(errors):
    errors=np.asarray(errors,dtype=float)
    if not errors.size:
        return {'n':0,'mae_ha':None,'rmse_ha':None,'max_abs_ha':None}
    return dict(n=int(errors.size),mae_ha=float(np.mean(abs(errors))),
                rmse_ha=float(np.sqrt(np.mean(errors**2))),max_abs_ha=float(max(abs(errors))))
