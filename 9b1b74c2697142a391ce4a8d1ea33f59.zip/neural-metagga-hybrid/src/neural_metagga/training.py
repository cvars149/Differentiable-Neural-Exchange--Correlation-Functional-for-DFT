import jax
import jax.numpy as jnp
import optax
from .energy import coefficients


def train(solvers,records,params,epochs=101,learning_rate=.003,callback=None):
    optimizer=optax.chain(optax.clip_by_global_norm(1.),optax.adamw(learning_rate,weight_decay=1e-5))
    state=optimizer.init(params);history=[]
    starts={n:(d['wa'],d['wb']) for n,(d,_) in records.items()}
    gradients={n:jax.jit(jax.value_and_grad(lambda p,ca,cb,t,e=s.energy:
               jnp.abs(e.from_coefficients(ca,cb,p)-t))) for n,s in solvers.items()}
    for epoch in range(epochs):
        total=0.;max_residual=0.;g_sum=jax.tree_util.tree_map(jnp.zeros_like,params)
        for name,(data,ref) in records.items():
            solver=solvers[name];r=solver.solve(params,*starts[name])
            if not r.converged:
                raise RuntimeError(f'{name}: nonstationary inner solve, residual={r.residual:g}; training stopped')
            starts[name]=(r.wa,r.wb)
            ca,cb=[jax.lax.stop_gradient(coefficients(w,solver.energy.data['D'])) for w in starts[name]]
            loss,g=gradients[name](params,ca,cb,ref['ccsd_t'])
            total+=float(loss);max_residual=max(max_residual,r.residual)
            g_sum=jax.tree_util.tree_map(lambda a,b:a+b,g_sum,g)
        g_mean=jax.tree_util.tree_map(lambda a:a/len(records),g_sum)
        update,state=optimizer.update(g_mean,state,params);params=optax.apply_updates(params,update)
        history.append(dict(epoch=epoch,train_mae_ha_pre_update=total/len(records),max_orbital_residual=max_residual,
                            alpha_post_update=float(.5*jax.nn.sigmoid(params['params']['alpha_ex_raw']))))
        if callback:
            callback(params,state,history)
    return params,history
