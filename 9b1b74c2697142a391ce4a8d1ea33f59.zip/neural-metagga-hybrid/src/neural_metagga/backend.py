"""PySCF preparation and explicitly checked finite-basis references."""
import json
from pathlib import Path
import numpy as np
from pyscf import gto,scf,dft,cc
from .numerics import whitening


def prepare(spec,basis,grid_level,max_eri_gib=2):
    mol=gto.M(atom=spec['coords'],spin=spec['spin'],charge=spec.get('charge',0),
              basis=basis,unit='Angstrom',verbose=0)
    gib=mol.nao_nr()**4*8/2**30
    if gib>max_eri_gib:
        raise MemoryError(f'Dense ERIs alone require about {gib:.2f} GiB')
    grid=dft.gen_grid.Grids(mol);grid.level=grid_level;grid.build()
    ao=dft.numint.eval_ao(mol,grid.coords,deriv=1)
    s=mol.intor('int1e_ovlp')
    data=dict(S=s,D=whitening(s),hcore=mol.intor('int1e_kin')+mol.intor('int1e_nuc'),
              kinetic=mol.intor('int1e_kin'),eri=mol.intor('int2e'),enuc=np.asarray(mol.energy_nuc()),
              weights=grid.weights,phi=ao[0],grad_phi=ao[1:].transpose(1,2,0))
    hf=scf.UHF(mol) if mol.spin else scf.RHF(mol)
    hf.conv_tol=1e-11;hf.max_cycle=200;hf.kernel()
    if not hf.converged:
        raise RuntimeError('HF reference failed to converge')
    mos,occs=(hf.mo_coeff,hf.mo_occ) if mol.spin else ((hf.mo_coeff,hf.mo_coeff),(hf.mo_occ/2,hf.mo_occ/2))
    for label,c,o in zip(('a','b'),mos,occs):
        data['w'+label]=c[:,np.asarray(o)>0].T@s@data['D']
    ref=dict(hf=float(hf.e_tot),hf_converged=True,spin=mol.spin,nelectron=mol.nelectron,
             hf_s2=float(hf.spin_square()[0]) if mol.spin else 0.,
             reference_type='UHF/UCCSD(T)' if mol.spin else 'RHF/RCCSD(T)',eri_gib=gib)
    coupled=cc.UCCSD(hf) if mol.spin else cc.CCSD(hf)
    coupled.conv_tol=1e-10;coupled.conv_tol_normt=1e-8;coupled.max_cycle=200;coupled.kernel()
    if not coupled.converged:
        raise RuntimeError('CCSD did not converge; refusing to substitute a different target')
    triples=float(coupled.ccsd_t())
    ref.update(ccsd=float(coupled.e_tot),triples=triples,ccsd_t=float(coupled.e_tot+triples),ccsd_converged=True)
    for name,xc in [('xonly','slater,'),('lda_vwn','lda,vwn'),('pbe','pbe,pbe'),('pbe0','pbe0')]:
        mf=dft.UKS(mol);mf.xc=xc;mf.grids=grid;mf.small_rho_cutoff=0
        mf.conv_tol=1e-10;mf.max_cycle=200;mf.kernel()
        if not mf.converged:
            raise RuntimeError(f'{name} UKS did not converge')
        ref[name]=float(mf.e_tot);ref[name+'_s2']=float(mf.spin_square()[0])
    if not all(np.isfinite(v) for v in ref.values() if isinstance(v,(float,int))):
        raise FloatingPointError('Nonfinite reference data')
    return data,ref


def save(folder,data,ref):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(folder/'integrals.npz',**data)
    (folder/'references.json').write_text(json.dumps(ref,indent=2,allow_nan=False))


def load(folder):
    folder=Path(folder)
    with np.load(folder/'integrals.npz',allow_pickle=False) as z:
        data={k:z[k] for k in z.files}
    return data,json.loads((folder/'references.json').read_text())
