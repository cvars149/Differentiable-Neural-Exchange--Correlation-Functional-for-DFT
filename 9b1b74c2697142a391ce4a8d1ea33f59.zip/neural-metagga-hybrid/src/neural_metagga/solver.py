from dataclasses import dataclass
import numpy as np
import jax
import jax.numpy as jnp
import optax
from .energy import coefficients,fields


@dataclass
class Result:
    wa: object
    wb: object
    energy: float
    converged: bool
    residual: float
    orthogonality: float
    history: list


class Solver:
    def __init__(self,energy,max_steps=2000,learning_rate=.02,energy_tol=1e-9,orbital_tol=1e-5,check_every=20):
        self.energy=energy;self.max_steps=max_steps;self.energy_tol=energy_tol
        self.orbital_tol=orbital_tol;self.check_every=check_every
        optimizer=optax.adam(optax.cosine_decay_schedule(learning_rate,max_steps,alpha=.05))
        self.optimizer=optimizer
        @jax.jit
        def step(w,state,params):
            _,g=jax.value_and_grad(lambda pair:energy(*pair,params))(w)
            update,state=optimizer.update(g,state,w)
            return optax.apply_updates(w,update),state
        self.step=step;self.evaluate=jax.jit(energy)
        self.coeff_grad=jax.jit(jax.grad(energy.from_coefficients,argnums=(0,1)))

    def diagnostics(self,w,params):
        d=self.energy.data
        cs=[coefficients(x,d['D']) for x in w]
        grads=self.coeff_grad(*cs,params)
        residual=0.;orth=0.
        for c,g in zip(cs,grads):
            z=c@d['S']@d['D'];gz=g@d['D']
            tangent=gz-.5*(gz@z.T+z@gz.T)@z
            residual+=jnp.sum(tangent**2)
            orth=jnp.maximum(orth,jnp.linalg.norm(c@d['S']@c.T-jnp.eye(c.shape[0])))
        return float(jnp.sqrt(residual/max(sum(c.size for c in cs),1))),float(orth)

    def solve(self,params,wa,wb):
        w=(jnp.asarray(wa),jnp.asarray(wb));state=self.optimizer.init(w)
        previous=None;history=[];converged=False
        for step in range(1,self.max_steps+1):
            w,state=self.step(w,state,params)
            if step%self.check_every and step!=self.max_steps:
                continue
            e=float(self.evaluate(*w,params));residual,orth=self.diagnostics(w,params)
            if not np.isfinite(e+residual+orth):
                raise FloatingPointError('Nonfinite orbital solve')
            delta=abs(e-previous) if previous is not None else float('inf')
            history.append(dict(step=step,energy_ha=e,residual=residual,orthogonality=orth))
            if delta<self.energy_tol and residual<self.orbital_tol and orth<1e-8:
                converged=True;break
            previous=e
        return Result(*w,e,converged,residual,orth,history)

    def physical_diagnostics(self,result):
        d=self.energy.data;counts=[];grid_counts=[];tau_energy=0.;kinetic=0.
        for w in (result.wa,result.wb):
            c=coefficients(w,d['D']);p=c.T@c
            rho,_,tau=fields(c,d['phi'],d['grad_phi'])
            counts.append(float(jnp.sum(p*d['S'])))
            grid_counts.append(float(jnp.dot(d['weights'],rho)))
            tau_energy+=float(jnp.dot(d['weights'],tau))
            kinetic+=float(jnp.sum(p*d['kinetic']))
        return dict(electrons_ao=counts,electrons_grid=grid_counts,
                    kinetic_ao_ha=kinetic,kinetic_grid_ha=tau_energy,
                    kinetic_grid_error_ha=tau_energy-kinetic)
