"""Experimental neural global-hybrid density functional learning."""
__version__ = "0.2.0"
