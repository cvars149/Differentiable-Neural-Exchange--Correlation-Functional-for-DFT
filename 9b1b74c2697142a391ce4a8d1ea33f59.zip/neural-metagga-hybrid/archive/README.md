# Legacy provenance

legacy_colab_export.py is a byte-for-byte copy of the supplied attachment.
It is a different, older 6-31g experiment and contains notebook syntax. It is not
imported, installed, tested as a Python module or presented as validated results.
See docs/CODE_AUDIT.md before interpreting its claims. The main project derives
from the separate def2-SVP prototype pasted into the conversation.
