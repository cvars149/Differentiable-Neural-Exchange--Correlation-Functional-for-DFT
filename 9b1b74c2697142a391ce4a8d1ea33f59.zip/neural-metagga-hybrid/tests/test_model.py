import pytest
jax=pytest.importorskip('jax');pytest.importorskip('flax')
jax.config.update('jax_enable_x64',True)
import numpy as np
import jax.numpy as jnp
from neural_metagga.model import NeuralMetaGGA,initialize
from neural_metagga.energy import fields


def test_spin_symmetry_nonzero_head():
    model=NeuralMetaGGA(width=8,depth=1);p=initialize(model)
    p['params']['head']['kernel']=jnp.ones_like(p['params']['head']['kernel'])*.1
    r=jnp.array([.1,.3]);g=jnp.ones((2,3))
    a=model.apply(p,r,2*r,g,3*g,r,4*r);b=model.apply(p,2*r,r,3*g,g,4*r,r)
    for x,y in zip(a,b):
        np.testing.assert_allclose(x,y,atol=1e-13)
    assert np.all(np.asarray(a[0])>=.5) and np.all(np.asarray(a[0])<=1.5)


def test_empty_channel():
    rho,grad,tau=fields(jnp.zeros((0,3)),jnp.ones((5,3)),jnp.ones((5,3,3)))
    np.testing.assert_array_equal(rho,np.zeros(5));np.testing.assert_array_equal(tau,np.zeros(5))
    assert grad.shape==(5,3)
