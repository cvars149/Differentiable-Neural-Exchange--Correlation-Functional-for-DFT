import pytest
np=pytest.importorskip('numpy');pytest.importorskip('pyscf')
jax=pytest.importorskip('jax');pytest.importorskip('flax');jax.config.update('jax_enable_x64',True)
from pyscf import gto,scf,dft
from neural_metagga.numerics import whitening,jk_energy
from neural_metagga.model import NeuralMetaGGA,initialize
from neural_metagga.energy import Energy


@pytest.mark.integration
def test_jk_reference():
    mol=gto.M(atom='H 0 0 0; H 0 0 .74',basis='sto-3g',verbose=0)
    rng=np.random.default_rng(3);a=rng.normal(size=(mol.nao,2));b=rng.normal(size=(mol.nao,2))
    pa,pb=a@a.T,b@b.T;vj,vk=scf.hf.get_jk(mol,np.stack([pa,pb]),hermi=1)
    expected=(.5*np.einsum('ij,ji->',pa+pb,vj[0]+vj[1]),
              -.5*(np.einsum('ij,ji->',pa,vk[0])+np.einsum('ij,ji->',pb,vk[1])))
    np.testing.assert_allclose(jk_energy(pa,pb,mol.intor('int2e')),expected,atol=1e-11)


@pytest.mark.integration
def test_same_orbital_xonly_energy():
    mol=gto.M(atom='H 0 0 0; H 0 0 .74',basis='sto-3g',verbose=0)
    mf=dft.UKS(mol);mf.xc='slater,';mf.grids.level=2;mf.small_rho_cutoff=0
    mf.conv_tol=1e-11;mf.kernel();assert mf.converged
    ao=dft.numint.eval_ao(mol,mf.grids.coords,deriv=1);s=mol.intor('int1e_ovlp')
    data=dict(S=s,D=whitening(s),hcore=mf.get_hcore(),eri=mol.intor('int2e'),enuc=mol.energy_nuc(),
              weights=mf.grids.weights,phi=ao[0],grad_phi=ao[1:].transpose(1,2,0))
    ca,cb=[c[:,o>0].T for c,o in zip(mf.mo_coeff,mf.mo_occ)]
    model=NeuralMetaGGA();energy=Energy(data,model,'xonly')
    np.testing.assert_allclose(float(energy.from_coefficients(ca,cb,initialize(model))),mf.e_tot,atol=1e-8)
