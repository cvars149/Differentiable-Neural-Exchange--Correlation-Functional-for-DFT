import numpy as np
import pytest
from neural_metagga.numerics import whitening,jk_energy,dirac_density,error_metrics


def test_whitening():
    rng=np.random.default_rng(0);a=rng.normal(size=(6,6));s=a.T@a+np.eye(6)
    d=whitening(s);q=np.linalg.qr(rng.normal(size=(6,3)))[0];c=q.T@d.T
    np.testing.assert_allclose(c@s@c.T,np.eye(3),atol=1e-12)


def test_singular_overlap():
    with pytest.raises(ValueError):
        whitening(np.diag([1.,0.]))


def test_one_electron_exchange_cancellation():
    rng=np.random.default_rng(2);b=rng.normal(size=(7,4,4));b=(b+b.transpose(0,2,1))/2
    eri=np.einsum('pij,pkl->ijkl',b,b);c=rng.normal(size=4);c/=np.linalg.norm(c)
    j,k=jk_energy(np.outer(c,c),np.zeros((4,4)),eri)
    np.testing.assert_allclose(j+k,0,atol=1e-12)


def test_dirac_limits():
    rho=np.array([0.,.1,1.,2.])
    np.testing.assert_allclose(dirac_density(rho/2,rho/2),-.7385587663820224*rho**(4/3))
    np.testing.assert_allclose(dirac_density(rho,0),2**(1/3)*dirac_density(rho/2,rho/2))


def test_metrics():
    m=error_metrics([1,-1,0]);assert m['n']==3
    np.testing.assert_allclose(m['mae_ha'],2/3)
    assert error_metrics([])['mae_ha'] is None
