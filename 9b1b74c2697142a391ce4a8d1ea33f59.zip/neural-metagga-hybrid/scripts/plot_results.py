"""Plot only actual, converged evaluation rows; matplotlib is optional."""
import argparse
import csv
from pathlib import Path
import matplotlib.pyplot as plt


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('csv')
    args=parser.parse_args();path=Path(args.csv)
    with path.open() as f:
        rows=list(csv.DictReader(f))
    rows=[r for r in rows if r['converged'].lower()=='true']
    if not rows:
        raise SystemExit('No converged rows to plot')
    fig,ax=plt.subplots(figsize=(9,4))
    ax.bar([r['molecule'] for r in rows],[float(r['abs_error_kcal_mol']) for r in rows],
           color=['#2563eb' if r['split']=='train' else '#ea580c' for r in rows])
    ax.set_ylabel('Absolute energy error (kcal/mol)')
    ax.set_title('Converged model energies; blue=train, orange=test')
    fig.tight_layout();fig.savefig(path.with_suffix('.png'),dpi=180)


if __name__=='__main__':
    main()
