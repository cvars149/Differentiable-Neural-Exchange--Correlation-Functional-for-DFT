"""Directional energy-gradient check using perturbed orbital re-solves."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from jax.flatten_util import ravel_pytree
from flax import serialization
from neural_metagga.backend import load
from neural_metagga.model import NeuralMetaGGA,initialize
from neural_metagga.energy import Energy,coefficients
from neural_metagga.solver import Solver


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--run-dir',required=True)
    p.add_argument('--molecule',required=True);p.add_argument('--seed',type=int,default=17)
    args=p.parse_args();run=Path(args.run_dir);cfg=json.loads(Path(args.config).read_text())
    digest=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
    if json.loads((run/'manifest.json').read_text())['config_sha256']!=digest:
        raise ValueError('Config does not match prepared run')
    model=NeuralMetaGGA(**cfg['model']);params=initialize(model,cfg['seed'])
    if (run/'parameters.msgpack').exists():
        params=serialization.from_bytes(params,(run/'parameters.msgpack').read_bytes())
    data,_=load(run/'data'/args.molecule);energy=Energy(data,model)
    solver=Solver(energy,**cfg['solver']);base=solver.solve(params,data['wa'],data['wb'])
    if not base.converged:
        raise RuntimeError('Base solve is not stationary')
    ca,cb=[coefficients(w,energy.data['D']) for w in (base.wa,base.wb)]
    grad=jax.grad(lambda par:energy.from_coefficients(ca,cb,par))(params)
    flat,unravel=ravel_pytree(params);g,_=ravel_pytree(grad)
    v=jax.random.normal(jax.random.PRNGKey(args.seed),flat.shape,dtype=flat.dtype);v/=jnp.linalg.norm(v)
    expected=float(jnp.vdot(g,v));rows=[]
    for h in (1e-3,3e-4,1e-4,3e-5,1e-5,3e-6,1e-6):
        minus=solver.solve(unravel(flat-h*v),base.wa,base.wb)
        plus=solver.solve(unravel(flat+h*v),base.wa,base.wb)
        fd=(plus.energy-minus.energy)/(2*h)
        rows.append(dict(h=h,envelope=expected,finite_difference=fd,absolute_error=abs(expected-fd),
            relative_error=abs(expected-fd)/max(abs(expected),abs(fd),1e-12),
            minus_residual=minus.residual,plus_residual=plus.residual,both_converged=minus.converged and plus.converged))
    with (run/f'envelope_{args.molecule}_seed{args.seed}.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(rows,indent=2))
    if not all(r['both_converged'] for r in rows):
        raise SystemExit('Perturbed convergence failed; comparisons are not validated')


if __name__=='__main__':
    main()
