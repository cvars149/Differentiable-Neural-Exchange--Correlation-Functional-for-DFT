# Contributing

Separate solver, functional, dataset and reporting changes into reviewable commits.
Add a regression test for numerical fixes and cite primary sources for new formulas.
Run `pip install -e '.[dev]'`, `pip check`, `pytest -v`, and smoke prepare/validate.
Document JAX backend, precision, package versions and all convergence failures.
Never replace failed high-level references with low-level energies under the same label.
Do not suppress warnings globally or commit dense ERIs/checkpoints.
A claimed accuracy improvement needs matched settings and a held-out evaluation.
