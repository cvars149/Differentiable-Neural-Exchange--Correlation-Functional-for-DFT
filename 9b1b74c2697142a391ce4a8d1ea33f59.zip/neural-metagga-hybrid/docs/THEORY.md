# Mathematical notes and conventions

## AO energy

Use real occupied orbital rows C_sigma, spin densities P_sigma=C_sigma.T C_sigma,
and PySCF chemist-notation ERIs (ij|kl). For P=P_a+P_b:

E_core = sum_ij P_ij h_ij.
E_H = (1/2) sum_ijkl P_ij P_kl (ij|kl).
E_x^HF = -(1/2) sum_sigma,ijkl P_sigma,il P_sigma,jk (ij|kl).

Alternative exchange index patterns may be equivalent by ERI symmetry.
The single-electron cancellation test is useful but not sufficient; the integration
test compares J/K with PySCF for arbitrary symmetric spin densities.
Only a full exact-exchange contribution cancels the one-electron Hartree term.
A 15% hybrid does not achieve full cancellation merely because its J/K algebra is correct.

## Whitening and QR

D=U diag(s^-1/2), D.T S D=I. The absence of a terminal U.T is intentional:
D need not equal the symmetric inverse square root. If W.T=QR, C=Q.T D.T
satisfies C S C.T=I. Near-zero overlap eigenvalues are rejected instead of clipped.
A production rank-reduction scheme would change the AO dimension explicitly.
QR gradients can become ill-conditioned at rank-deficient W.

## Grid contractions

The array layouts are phi[g,b], grad_phi[g,b,x], C[i,b].
psi[g,i]=phi[g,b] C[i,b], grad_psi[g,i,x]=grad_phi[g,b,x] C[i,b].
rho=sum_i psi^2, grad_rho=2 sum_i psi grad_psi,
tau=(1/2) sum_i,x grad_psi^2. Electron counts should agree with Tr(P_sigma S).
Integral tau should approach Tr(P T) as quadrature improves; the CLI exports both.
No occupancy factor of two is applied within a spin channel.

## Correlation provenance

The inherited expression is epsilon_c=a log(1+b/r_s+b/r_s^2),
r_s=(3/(4 pi rho))^(1/3), a=-0.01554535, b=20.64336.
It is independent of zeta and therefore not a full spin-polarized correlation.
The constants originate from the supplied prototype; primary-paper convention
verification was not completed. This is stated explicitly rather than disguising
a new unverified interpolation as a correction. Density floors stabilize descriptors,
while Dirac exchange uses its volume-energy expression to avoid a clipped denominator.

## Symmetry and constraints

A shared MLP evaluates x and spin-swap(x); average its raw outputs. Swapping both
spin channels leaves the final XC energy unchanged. Scalar gradient norms and
kinetic densities provide spatial rotation-invariant semilocal inputs.
This does not imply noncollinear spin invariance, one-electron correlation cancellation,
uniform coordinate scaling, a rigorous Lieb-Oxford bound, or correct fractional-spin behavior.
The bounded output factors are a numerical stabilization heuristic only.

## Orbital convergence

Let c=z D.T. In orthonormal coordinates grad_z=grad_c D and z=c S D.
The Stiefel tangent gradient is G - sym(G z.T) z. Its RMS norm is independent
of arbitrary scaling of W, unlike the raw W gradient. The solver requires a small
projected residual, a small energy change across checks, and orthogonality error
below 1e-8. None of these proves a global minimum or branch uniqueness.

## Envelope differentiation

For a differentiable stationary solution branch, E*(theta)=E(W*(theta),theta).
The chain-rule term dE/dW times dW*/dtheta vanishes at stationarity; equivalently
use a constrained Lagrangian whose orthogonality constraint is theta-independent.
For total-energy MAE, apply the absolute-value subgradient to this energy derivative.
At zero residual error in the objective, absolute value is nondifferentiable.

For approximate orbitals the omitted response term is generally nonzero.
A small residual alone does not bound it without a bound on orbital response.
Degenerate states, branch switching and nonunique minima require care.
Re-solved central finite differences test the energy gradient, not force/density
response or global optimality. Perturbation step-size convergence is essential.

## References

See README references [1–4] and docs/LITERATURE.md for source scope. The derivations
above specify this implementation's real-orbital and row-coefficient conventions.
