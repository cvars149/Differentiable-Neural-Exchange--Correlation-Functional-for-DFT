# Validation status

This release was packaged as a research scaffold, not a validated chemistry engine.
Actual packaging checks are recorded in BUILD_VALIDATION.json.

Executed: syntax parsing of all new package/test/script files; NumPy-only pytest
suite; configuration/ZIP checks. JAX, Flax, Optax and PySCF were unavailable.
Not executed: model/backend tests, reference generation, orbital minimization,
finite-difference envelope checks, training, scientific CI or GPU benchmarks.
No numerical benchmark results, trained weights or timing claims are included.

The dependency ranges are provisional, not a tested lockfile. A clean install must
resolve the scientific stack and pass CI before release claims. The CI workflow is
supplied but no successful remote run is asserted.

Known limitations: spin-independent prototype correlation; no full exact constraints;
small pilot split without validation; dense O(B^4) ERIs; potential rank/branch issues;
no solver guarantee at the chosen tolerances; optimizer state saved but resume absent;
no force/density response implementation; checkpoints are not atomic; array hashes
and full data/code provenance are not automatically recorded.

The corrected default intentionally changes the prototype and has no measured
accuracy comparison to that version. Architecture switches are ablations, not bitwise
reproduction. The older export is archived unmodified, not executable package source.
