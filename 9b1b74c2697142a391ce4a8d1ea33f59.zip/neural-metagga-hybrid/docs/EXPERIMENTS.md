# Research validation protocol

## Gate 1: algebra and common-orbital evaluation

Run pytest. Test overlap orthogonality, one-electron Hartree/exchange cancellation,
spin-scaled Dirac limits, metrics, nonzero-head spin symmetry, empty spin channels,
arbitrary-density J/K versus PySCF, and x-only total energy on identical UKS orbitals.
Only dependency-free tests were executed while packaging.

## Gate 2: orbital minimization

Run prepare and validate. Compare same-grid UKS x-only with direct minimization.
Inspect all starts, projected residuals, AO/grid electron counts and AO/grid kinetic
energy. Repeat levels 3/4/5, multiple seeds and tighter solver tolerances. A lower
energy needs local-minimum and spin-symmetry analysis; it is not necessarily a bug
or an accuracy gain over the physical reference.

## Gate 3: training gradient

Run scripts/check_envelope.py on H2, He and at least one open-shell system.
Repeat parameter directions and inner tolerances, inspect step-size plateaus and
branch changes. Small residuals alone do not certify gradient accuracy. Introduce
deliberately loose solves to quantify the bias from approximate stationarity.

## Gate 4: causal ablations

Implement and compare: x-only, x+prototype correlation, fixed-alpha hybrid,
alpha-only fitting, neural-only fitting, full hybrid, spin-symmetric versus ordered
features, bounded versus unbounded outputs. x-only/local/hybrid energy modes exist,
but the CLI currently exposes x-only validation and full-hybrid training/evaluation;
the remaining optimizer-freezing ablations are not implemented.

## Gate 5: chemical observables and transfer

Add atomization/reaction energies, spin gaps and dissociation curves. Generate
consistent atomic references with correct charges/spins and validate stretched-bond
reference quality. Separate new geometry, composition, size and element shifts.
Group related geometries in splits to avoid near-duplicate train/test leakage.
The pilot has no validation set: do not tune on CO, F2 or HF and call them untouched test.

## Reporting

Report MAE/RMSE/max error, signed errors, n, failure counts, per-start convergence,
multiple training seeds and reference provenance. Separate total-energy accuracy
from energy-difference accuracy. Record compile time, synchronized warm time,
memory, hardware, precision and exact environment. Do not infer favorable scaling
from nine small systems or call generated spherical point clouds fullerenes.

## Plausible research contributions, not established novelty

- A controlled study of envelope-gradient error versus orbital stationarity/conditioning.
- Constraint-aware reduced descriptors and open-shell transfer.
- Ablated benefits of a learned exchange fraction over fixed-alpha alternatives.
- Memory-efficient direct minimization with density fitting and grid chunking.

Compare to relevant prior art before claiming any of these contributions as novel.
