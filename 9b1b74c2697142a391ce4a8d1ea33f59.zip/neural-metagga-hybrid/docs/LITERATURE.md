# Literature review and evidence boundaries

Reviewed online on 1 November 2026. This is a focused source review, not an
exhaustive systematic review or a claim that every full paper was read.

## D4FT

Official repository: https://github.com/sail-sg/d4ft
Paper: https://openreview.net/forum?id=aBWnqqsuot7

The official repository documents direct minimization, SCF, HF options, configurable
XC, FP64 and PySCF cross-checks. It distinguishes energy evaluation at common orbitals
from comparing optimized energies. This is the closest solver-related foundation.
Our use of dense PySCF ERIs does not reproduce D4FT's own integral engine or its
scaling experiments. Do not attribute this project's learned functional to D4FT.
Evidence reviewed: repository documentation; paper identification from prior context.

## Differentiable XC learning / DQC

Kasim and Vinko, PRL 127, 126403 (2021).
https://doi.org/10.1103/PhysRevLett.127.126403
https://github.com/diffqc/dqc

The publisher abstract describes a neural XC functional trained in differentiable
3D KS-DFT using a small experimental dataset and evaluated on broader atomization
energies. The work establishes important prior art for functional learning through
molecular properties. Its reported numbers are not a benchmark for this repository.
Evidence reviewed: publisher abstract and implementation listing, not a full implementation audit.

## DM21

https://doi.org/10.1126/science.abj6511
https://doi.org/10.1126/science.abq3385
https://doi.org/10.1126/science.abq4282

The primary abstract emphasizes molecular data plus fractional-charge/spin systems.
A later comment questions the strength of certain generalization conclusions; the
authors' response disputes the analysis and discusses further examples. The useful
research lesson is to test constraints out of training distribution and document
split construction, not to treat a celebrated model as beyond scrutiny.
Evidence reviewed: primary abstract, comment and response excerpts. No model reproduction.

## EG-XC

Gao, Eberhard and Günnemann, ICLR 2025.
https://proceedings.iclr.cc/paper_files/paper/2025/hash/7d95d65059958ba8667be1f642c6447c-Abstract-Conference.html

Proceedings describe an SO(3)-equivariant nuclei-centered density point cloud,
equivariant GNN for nonlocal interactions, and differentiation through SCF with
energy targets. This is more expressive/nonlocal than the present semilocal MLP.
Published dataset-specific improvements cannot be transferred to our split.
Evidence reviewed: official proceedings abstract; no full supplement or code audit.

## Skala and coupled-cluster dataset context

https://www.microsoft.com/en-us/research/project/dft/publications/

The institutional publication list identifies 2025 work on scalable deep-learning XC
and the Accurate Chemistry Collection, and 2026 work on a molecular Skala implementation.
That establishes a relevant reading direction, not verified architecture details,
code availability, publication venue, or an apples-to-apples numerical comparison.
Evidence reviewed: institutional publication listing only.

## Numerical backend

https://pyscf.org/user/dft.html
https://pyscf.org/user/cc.html

The DFT guide explicitly supports the exchange-only comma convention, generalized-KS
interpretation, quadrature settings and tau-vs-AO kinetic-energy check used here.
Reference-method accuracy is not a substitute for convergence/stability diagnostics.

## Primary sources still requiring full review

The Chachiyo primary correlation paper and spin interpolation conventions; original
KS/generalized-KS derivations; full D4FT/DQC/DM21/EG-XC supplements; Skala full text;
benchmark protocols for W4-11/GMTKN55 and dataset licensing before integration.
No architecture claim should exceed the evidence scope listed above.
