# Module and artifact guide

- numerics.py: NumPy overlap/J/K/Dirac algebra and summary metrics.
- model.py: spin-symmetric bounded residual network and global hybrid fraction.
- energy.py: orbital fields, real-AO energy and x-only/local/hybrid modes.
- backend.py: PySCF integrals, HF starts and checked reference calculations.
- solver.py: reusable JIT steps, stationarity and physical diagnostics.
- training.py: warm-start stationarity-gated energy MAE envelope training.
- cli.py: four explicit experiment stages with persistent artifacts.
- scripts/check_envelope.py: parameter-direction energy derivative check.
- scripts/plot_results.py: plot converged errors from real evaluation CSV.

Run from the repository root after editable installation. Do not import archive/.
Store separate configs and run directories for every changed scientific setting.
A config hash is checked, but existing data arrays are not cryptographically verified.
The current prepare stage recomputes reference data rather than resuming partial runs.
The optimizer checkpoint is retained for future work; there is no resume command.

Publishing: choose a license, verify legacy ownership/attribution, run CI, and then
initialize Git or upload this source tree to an empty repository. Replace the remote
placeholder in README with your actual remote. No account/remote was accessed while
building this archive. Generated runs are excluded from source control by default.
