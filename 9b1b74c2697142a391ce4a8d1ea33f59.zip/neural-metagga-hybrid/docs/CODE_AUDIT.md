# Audit of supplied versions

## Main pasted prototype (def2-SVP)

- `lda,` omits correlation; both the PySCF and custom non-neural branches are x-only.
  This baseline is valid if labeled accurately, but not a complete LSDA XC comparison.
- The stored PySCF x-only energies are not used in the final dashboard. Comparing
  only to CCSD(T) does not establish solver correctness.
- PySCF's default grid differs from the explicitly constructed level-4 grid.
- Spin-zero custom orbitals are unrestricted; RKS baselines search a smaller domain.
- Whitening and the final exact-exchange contraction are consistent. The density
  gradients and tau contractions are shape-consistent in the supplied code.
- The learned exchange fraction begins near 15%, not 30%, due to the extra factor 0.5.
- A zero neural head starts the model as a hybrid with correlation, not as x-only LSDA.
  Hidden layers initially receive zero gradient until the output head changes.
- Signed zeta and ordered spin features can violate global spin-label symmetry.
- Correlation lacks spin dependence. The iso-orbital feature is not the conventional
  meta-GGA alpha normalized by the uniform-gas kinetic density.
- Features use fixed atomic-unit values rather than dimensionless reduced descriptors.
- Unbounded correction factors permit pathological energy lowering.
- Global JAX FP64 configuration does not alone make Flax Dense parameters FP64.
- Fixed 600 steps and a decaying learning rate do not certify stationarity.
- `history[-1]` is the pre-update energy, inconsistent with returned final W.
- Defining JIT anew while capturing changing neural parameters risks repeated compilation.
- Molecular loops are sequential; the phase title does not establish parallel execution.
- Random restarts every solve waste warm-start information, but warm starts alone
  can hide competing local branches. Use both strategies deliberately.
- Frozen-orbital gradients can be valid for stationary minimized-energy objectives.
  They require numerical verification at the actual convergence tolerance.
- No convergence flags, reference provenance, warnings, checkpoints or environment
  lockfile are retained. Suppressing all warnings hides potentially important signals.
- Six training and three test systems cannot establish universal chemical transfer.
  F appears only in test; total-energy MAE is not atomization-energy accuracy.

## Attached older export (6-31g)

This is a different experiment, preserved byte-for-byte under archive/.
It contains notebook-specific installation syntax and apparent structural damage
as standalone Python. It is not imported or included in package syntax checks.

The earlier file declares a neural basis scaler that is not connected to the main
energy calculation. A positive local scale does not prove a globally bijective
coordinate transformation or overlap preservation without additional assumptions.
Its neural magnetism comparison reuses a closed-shell solve for both spin labels.
Its generated carbon-on-sphere coordinates are not verified fullerene structures.
Dummy ERIs and softened/excluded grid Coulomb terms do not reproduce the original
Hamiltonian. Pair sampling needs a properly normalized estimator and self-term policy.
Reference failure can fall back to LDA, undermining a uniform CCSD(T) label.
These issues preclude treating those experiments as validated fullerene scaling,
learned-basis improvement, or neural magnetism results.

## Refactor scope

Default symmetrization, bounded residuals, FP64 parameters, HF starts, strict
stationarity gates, matched UKS and shared grids intentionally change behavior.
No numerical continuity with an earlier reported result has been demonstrated.
