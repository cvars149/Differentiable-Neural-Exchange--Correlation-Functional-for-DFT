# License decision required

No open-source license has been selected on the author's behalf. Choose a license
and add its full LICENSE text before distributing the project as open source.
Verify rights and attribution for the archived notebook-derived source and review
upstream dependency licenses. Source availability is not itself a license grant.
